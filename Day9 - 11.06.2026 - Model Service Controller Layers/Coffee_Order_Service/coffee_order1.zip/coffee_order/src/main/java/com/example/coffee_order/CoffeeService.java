package com.example.coffee_order;

import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class CoffeeService {
    private final List<String> order = new ArrayList<>();
    public String orderCof(String type){
        order.add(type);
        return "Order placed for: "+type;
    }
    public List<String> getOrder(){
        return order;
    }
}

